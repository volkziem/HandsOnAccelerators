% DD.m, drift space
function out=DD(L)
out=[1,L;0,1];
