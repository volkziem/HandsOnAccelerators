% Q.m thin quadrupole
function out=Q(F)
out=eye(3);
if abs(F)<1e-8 return; end
out(2,1)=-1/F;
