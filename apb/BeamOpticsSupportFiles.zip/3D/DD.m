% DD.m, drift space
function out=DD(L)
out=eye(3);
out(1,2)=L;

