% QQ.m, quadrupole
function out=QQ(L,k1)
ksq=sqrt(abs(k1));
out=eye(3);
if abs(k1) < 1e-6
    out(1,2)=L;
elseif k1>0
    out(1:2,1:2)=[cos(ksq*L),sin(ksq*L)/ksq;-ksq*sin(ksq*L),cos(ksq*L)];    
else
    out(1:2,1:2)=[cosh(ksq*L),sinh(ksq*L)/ksq;ksq*sinh(ksq*L),cosh(ksq*L)];
end
