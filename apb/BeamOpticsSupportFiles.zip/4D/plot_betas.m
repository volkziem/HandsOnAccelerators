% plot_betas.m, V. Ziemann
function plot_betas(beamline,sigma0)
[Racc,spos,nmat,nlines]=calcmat(beamline);
betax=zeros(1,nmat); betay=betax;
for k=1:nmat
   sigma=Racc(:,:,k)*sigma0*Racc(:,:,k)';
   betax(k)=sigma(1,1); betay(k)=sigma(3,3);
end
plot(spos,betax,'k',spos,betay,'r-.'); 
xlabel(' s[m]'); ylabel('\beta_x,\beta_y [m]')
legend('\beta_x','\beta_y')
axis([0, max(spos), 0, 1.05*max([betax,betay])])
end
