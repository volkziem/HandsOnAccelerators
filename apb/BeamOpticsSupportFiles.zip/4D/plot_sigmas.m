% plot_sigmas.m
function plot_sigmas(beamline,sigma0)
[Racc,spos,nmat,nlines]=calcmat(beamline);
sigmax=zeros(nmat,1); sigmay=sigmax;   % allocate space
for k=1:nmat
   sigma=Racc(:,:,k)*sigma0*Racc(:,:,k)';
   sigmax(k)=sqrt(sigma(1,1)); sigmay(k)=sqrt(sigma(3,3));
end
plot(spos,sigmax,'k',spos,sigmay,'k-.'); 
xlabel(' s[m]'); ylabel('\sigma_x,\sigma_y [m]')
legend('\sigma_x','\sigma_y')
axis([0, max(spos), 0, 1.05*max([sigmax,sigmay])])
end
